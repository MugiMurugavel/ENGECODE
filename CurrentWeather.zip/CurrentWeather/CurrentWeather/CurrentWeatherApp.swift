import SwiftUI

@main
struct CurrentWeatherApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
