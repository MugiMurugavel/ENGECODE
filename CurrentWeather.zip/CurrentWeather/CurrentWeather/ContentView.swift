import SwiftUI

struct ContentView: View {
    @ObservedObject var weatherViewModel = WeatherViewModel()

    var body: some View {
        ZStack {
            BackgroundView()
            
            VStack {
                if weatherViewModel.stateView  == .loading {
                    ActivityIndicatorView(isAnimating: true).configure {
                        $0.color = .white
                    }
                }
                
                if weatherViewModel.stateView  == .success {
                    LocationAndTemperatureHeaderView(data: weatherViewModel.currentWeather)
                    
                    Text(weatherViewModel.currentDescription)
                
                    
                    ScrollView(.vertical, showsIndicators: false) {
                        VStack {
                            
                            Rectangle().frame(height: CGFloat(1))
                            
                            HourlyWeatherView(data: weatherViewModel.hourlyWeathers)
                            Rectangle().frame(height: CGFloat(1))
                            
                        }
                    }
                    
                    
                    HStack {
                        
                        Button(action: {
                                }) {
                                    Image(systemName: "power")
                                        .resizable()
                                        .aspectRatio(contentMode: .fit)
                                        .frame(width: 100, height: 100)
                                        .padding(20)
                                        .background(Color.red)
                                        .foregroundColor(.white)
                                        .clipShape(Circle())
                                        .overlay(
                                            Circle()
                                                .stroke(Color.white, lineWidth: 2)
                                                .shadow(color: .black, radius: 2, x: 0, y: 0)
                                        )
                                }
                        
                        VStack {
                            Button(action: {
                                    }) {
                                        Image(systemName: "chevron.up")
                                            .resizable()
                                            .aspectRatio(contentMode: .fit)
                                            .frame(width: 50, height: 50)
                                            .padding(20)
                                            .background(Color.blue)
                                            .foregroundColor(.white)
                                            .clipShape(Rectangle())
                                            .overlay(
                                                Rectangle()
                                                    .stroke(Color.white, lineWidth: 2)
                                                    .shadow(color: .black, radius: 2, x: 0, y: 0)
                                            )
                                    }
                            
                            Button(action: {
                                    }) {
                                        Image(systemName: "chevron.down")
                                            .resizable()
                                            .aspectRatio(contentMode: .fit)
                                            .frame(width: 50, height: 50)
                                            .padding(20)
                                            .background(Color.blue)
                                            .foregroundColor(.white)
                                            .clipShape(Rectangle())
                                            .overlay(
                                                Rectangle()
                                                    .stroke(Color.white, lineWidth: 2)
                                                    .shadow(color: .black, radius: 2, x: 0, y: 0)
                                            )
                                    }
                        }
                    }
                    
                    
                    Spacer()
                    
                    
                    Spacer()
                }
                
                if weatherViewModel.stateView == .failed {
                    Button(action: {
                        self.weatherViewModel.retry()
                    }) {
                        Text("Error Ocurred. Try Again")
                            .foregroundColor(.white)
                    }
                }
            }
        }
        .colorScheme(.dark)
    }
}
